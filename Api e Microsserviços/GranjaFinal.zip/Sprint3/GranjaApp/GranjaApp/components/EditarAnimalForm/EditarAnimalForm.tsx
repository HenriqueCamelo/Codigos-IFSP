import React, { useEffect, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type EditarAnimalRouteProp = RouteProp<RootStackParamList, "EditarAnimal">;

export default function EditarAnimalForm() {
  const route = useRoute<EditarAnimalRouteProp>();
  const navigation = useNavigation<NavigationProp>();
  const { idAnimal } = route.params;

  const [animal, setAnimal] = useState<any>(null);

  const [nomeAnimal, setNomeAnimal] = useState("");
  const [sexoAnimal, setSexoAnimal] = useState("");
  const [dataNascimentoAnimal, setDataNascimentoAnimal] = useState("");
  const [fazenda, setFazenda] = useState("");
  const [granja, setGranja] = useState("");
  const [paiAnimal, setPaiAnimal] = useState("");
  const [maeAnimal, setMaeAnimal] = useState("");
  const [vendedor, setVendedor] = useState("");
  const [precoAnimal, setPrecoAnimal] = useState("");
  const [dataCompra, setDataCompra] = useState("");
  const [dadosExtra, setDadosExtra] = useState("");

  useEffect(() => {
    const fetchAnimal = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await fetch(`http://localhost:8080/api/animals/${idAnimal}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        const data = await response.json();
        console.log("🐮 Animal carregado:", data);
        setAnimal(data);

        // Preenche os campos com os dados existentes
        setNomeAnimal(data.nomeAnimal);
        setSexoAnimal(data.sexoAnimal);
        setDataNascimentoAnimal(data.dataNascimentoAnimal);
        setFazenda(data.fazenda);
        setGranja(data.granja);
        setPaiAnimal(data.paiAnimal);
        setMaeAnimal(data.maeAnimal);
        setVendedor(data.vendedor);
        setPrecoAnimal(String(data.precoAnimal));
        setDataCompra(data.dataCompra);
        setDadosExtra(data.dadosExtra);
      } catch (error) {
        console.error("Erro ao carregar animal:", error);
        Alert.alert("Erro", "Falha ao carregar dados do animal.");
      }
    };

    fetchAnimal();
  }, [idAnimal]);

  const handleSave = async () => {
    if (!nomeAnimal || !sexoAnimal || !dataNascimentoAnimal) {
      Alert.alert("Erro", "Preencha ao menos os campos obrigatórios!");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`http://localhost:8080/api/animals/${idAnimal}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          nomeAnimal,
          sexoAnimal,
          dataNascimentoAnimal,
          fazenda,
          granja,
          paiAnimal,
          maeAnimal,
          vendedor,
          precoAnimal: parseFloat(precoAnimal),
          dataCompra,
          dadosExtra,
        }),
      });

      if (response.ok) {
        Alert.alert("Sucesso", "Animal atualizado com sucesso!");
        navigation.goBack();
      } else {
        const errorText = await response.text();
        console.error("Erro ao atualizar:", errorText);
        Alert.alert("Erro", "Falha ao atualizar o animal.");
      }
    } catch (error) {
      console.error("Erro de requisição:", error);
      Alert.alert("Erro", "Não foi possível conectar ao servidor.");
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Editar Animal</Text>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Nome do Animal</Text>
        <TextInput style={styles.input} value={nomeAnimal} onChangeText={setNomeAnimal} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Sexo</Text>
        <TextInput style={styles.input} value={sexoAnimal} onChangeText={setSexoAnimal} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Data de Nascimento</Text>
        <TextInput
          style={styles.input}
          value={dataNascimentoAnimal}
          onChangeText={setDataNascimentoAnimal}
          placeholder="AAAA-MM-DD"
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Fazenda</Text>
        <TextInput style={styles.input} value={fazenda} onChangeText={setFazenda} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Granja</Text>
        <TextInput style={styles.input} value={granja} onChangeText={setGranja} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Pai</Text>
        <TextInput style={styles.input} value={paiAnimal} onChangeText={setPaiAnimal} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Mãe</Text>
        <TextInput style={styles.input} value={maeAnimal} onChangeText={setMaeAnimal} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Vendedor</Text>
        <TextInput style={styles.input} value={vendedor} onChangeText={setVendedor} />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Preço</Text>
        <TextInput
          style={styles.input}
          value={precoAnimal}
          keyboardType="numeric"
          onChangeText={setPrecoAnimal}
        />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Data da Compra</Text>
        <TextInput style={styles.input} value={dataCompra} onChangeText={setDataCompra} placeholder="AAAA-MM-DD" />
      </View>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>Dados Extras</Text>
        <TextInput style={styles.input} value={dadosExtra} onChangeText={setDadosExtra} multiline />
      </View>

      <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSave}>
        <Text style={styles.buttonText}>Salvar</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.cancel]} onPress={() => navigation.goBack()}>
        <Text style={styles.buttonText}>Cancelar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: "#f8f9fa",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#198754",
    marginBottom: 20,
    textAlign: "center",
  },
  inputGroup: {
    marginBottom: 12,
  },
  label: {
    fontSize: 16,
    marginBottom: 4,
  },
  input: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#ced4da",
    borderRadius: 6,
    padding: 10,
  },
  button: {
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginVertical: 6,
  },
  save: {
    backgroundColor: "#198754",
  },
  cancel: {
    backgroundColor: "#dc3545",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
