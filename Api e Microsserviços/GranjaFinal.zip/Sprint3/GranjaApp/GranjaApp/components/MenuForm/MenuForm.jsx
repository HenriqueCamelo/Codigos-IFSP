import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, useWindowDimensions } from "react-native";

import { useNavigation } from '@react-navigation/native';

export default function MenuForm(){
    const { width } = useWindowDimensions();
    const isSmallScreen = width < 700;
    const navigation = useNavigation();
    return(
        
        <ScrollView contentContainerStyle={[
                        styles.container,
                        isSmallScreen && { flexGrow: 0 } 
                    ]}>
            <View style = {styles.header}>
                <Text style = {styles.headerTitle}>GranjaManagements</Text>
                <TouchableOpacity style={styles.logoutButton}>
                    <Text style ={styles.logoutText}>Sair</Text>
                </TouchableOpacity>
            </View>

            <View style = {styles.welcomeSection}>
                <Text style={styles.fazendaTitle}>Fazenda de Santa Mar</Text>
                <Text style={styles.subtitle}>Bem vindo</Text>
            </View>

            <View style = {styles.content}>
                <Text style= {styles.sectionTitle}>Gerenciamento</Text>
                
                <View
                style={[
                    styles.cardsContainer,
                    isSmallScreen && { paddingHorizontal: 0,flexDirection: "column", alignItems: "center", flexWrap: "nowrap" },
                ]}
                >
                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('MenuAnimais')}>
                    <Text style={styles.cardText}>🐄 Animais</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]}>
                    <Text style={styles.cardText}>📊 Relatórios</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('Despesa')}>
                    <Text style={styles.cardText}>💰 Despesas</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]}>
                    <Text style={styles.cardText}>💉 Vacinas</Text>
                </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        
        backgroundColor: "#f8f9fa",
        width: "100%",
    },
    header: {
        backgroundColor: "#218838",
        height: 60,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 20,
    },
    headerTitle: {
        color: "#fff",
        fontSize: 18,
        fontWeight: "bold",
    },
    logoutButton: {
        backgroundColor: "#dc3545",
        paddingVertical: 6,
        paddingHorizontal: 14,
        borderRadius: 6,
    },
    logoutText: {
        color: "#fff",
        fontWeight: "bold",
    },
    welcomeSection: {
        backgroundColor: "#212529",
        paddingVertical: 40,
        paddingHorizontal: 20,
    },
    fazendaTitle: {
        fontSize: 28,
        color: "#f8f9fa",
        fontStyle: "italic",
        fontWeight: "600",
    },
    subtitle: {
        color: "#b8b9ba",
        marginTop: 10,
        fontSize: 16,
    },
    content: {
        padding: 20
    },
    sectionTitle: {
        fontSize: 22,
        fontWeight: "600",
        marginBottom: 20,
        borderBottomWidth: 1,
        borderBottomColor: "#ccc",
        paddingBottom: 8,
    },
    cardsContainer: {
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
        paddingHorizontal: 240,
    },
    card: {
        width: "48%",
        backgroundColor: "#fff",
        borderRadius: 12,
        paddingVertical: 40,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 20,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 4},
        shadowOpacity: 0.15,
        shadowRadius: 5,
        elevation: 3,
    },
    cardText: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#333",
    }
})