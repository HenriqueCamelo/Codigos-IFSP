import React, {useState} from "react";
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native";
import { RootStackParamList } from '../../App'; 
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';

type PesoRouteProp = RouteProp<RootStackParamList, "Peso">;
type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function PesoForm(){
    
    const route = useRoute<PesoRouteProp>();
    const navigation = useNavigation<NavigationProp>();

    console.log("🟢 Parâmetros recebidos:", route.params);

    const { idAnimal } = route.params || {};

    if (!idAnimal) {
        console.warn("⚠️ Nenhum ID de animal foi recebido!");
    }  

    const [dataPesagem, setDataPesagem] = useState("");
    const [pesoAnimal, setPesoAnimal] = useState("");

    const handleSubmit = async () => {
    if (!dataPesagem || !pesoAnimal ) {
            Alert.alert("Erro", "Preencha todos os campos!");
            return;
        }
    
        try {
            const token = localStorage.getItem("token");
            console.log("📤 Enviando peso para animal ID:", idAnimal);
    
            const response = await fetch(`http://localhost:8080/api/pesos/animal/${idAnimal}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
                dataPesagem: dataPesagem,
                pesoAnimal: pesoAnimal,
            }),
            });
    
            if (response.ok) {
            Alert.alert("Sucesso", "Peso adicionado com sucesso!");
            navigation.goBack();
            } else {
            const errorText = await response.text();
            console.error("Erro ao cadastrar peso:", errorText);
            Alert.alert("Erro", "Falha ao cadastrar peso.");
            }
        } catch (error) {
            console.error("Erro de requisição:", error);
            Alert.alert("Erro", "Não foi possível conectar ao servidor.");
        }
    }

    return(
        //<SafeAreaView style={{ flex: 1, backgroundColor: "#f8f9fa" }}>
            <ScrollView contentContainerStyle = {styles.container}>
                <View style = {styles.formBox}>
                    <Text style = {styles.title}>Pesagem</Text>
                        <Text style={styles.subtitle}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Pesagem</Text> 
                            </TouchableOpacity >
                        </Text>
                    

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data da pesagem:</Text>
                            <TextInput 
                                style={styles.input}
                                value={dataPesagem}
                                onChangeText={setDataPesagem}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>


                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Peso:</Text>
                            <TextInput 
                                style={styles.input}
                                value={pesoAnimal}
                                keyboardType="numeric"
                                onChangeText={setPesoAnimal}
                                placeholder="Insira o peso da ave"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>



                    <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSubmit}>
                        <Text style={styles.buttonText}>Salvar</Text>
                    </TouchableOpacity>



                </View>
            </ScrollView>
        //</SafeAreaView>
    );
}

const styles = StyleSheet.create({
    link:{

    },
    container: {
        flexGrow: 1,
        alignItems: "center",
        padding: 20,
        backgroundColor: "#ebebebff",
    },
    formBox: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "95%",
        maxWidth: 600,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 4,
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        marginBottom: 20,
    },
    inputGroup: {
        marginBottom: 12,
    },
    label: {
        fontSize: 16,
        marginBottom: 4,
    },
    input: {
        backgroundColor: "#f8f9fa",
        borderWidth: 1,
        borderColor: "#ced4da",
        borderRadius: 6,
        padding: 10,
    },
    button: {
        width: "90%",
        alignSelf: "center",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginVertical: 6,
    },
    save: {
        backgroundColor: "#198754",
    },
    cancel: {
        backgroundColor: "#dc3545",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    }
})