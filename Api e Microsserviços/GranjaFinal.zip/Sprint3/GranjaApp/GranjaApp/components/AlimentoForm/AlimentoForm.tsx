import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from "react-native";
import { RouteProp, useRoute, useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";

type AddAlimentoRouteProp = RouteProp<RootStackParamList, "AddAlimento">;
type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function GranjaAddAlimentoScreen() {
  const route = useRoute<AddAlimentoRouteProp>();
  const navigation = useNavigation<NavigationProp>();

  // 👇 Adicione um log para garantir que está vindo certo
  console.log("🟢 Parâmetros recebidos:", route.params);

  const { idAnimal } = route.params || {};

  if (!idAnimal) {
    console.warn("⚠️ Nenhum ID de animal foi recebido!");
  }

  const [quantidadeRacao, setQuantidadeRacao] = useState("");
  const [quantidadeAgua, setQuantidadeAgua] = useState("");
  const [data, setData] = useState("");

  const handleSubmit = async () => {
    if (!quantidadeRacao || !quantidadeAgua || !data) {
      Alert.alert("Erro", "Preencha todos os campos!");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      console.log("📤 Enviando alimento para animal ID:", idAnimal);

      const response = await fetch(`http://localhost:8080/api/alimentos/animal/${idAnimal}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          quantidadeRacao: quantidadeRacao,
          quantidadeAgua: quantidadeAgua,
          dataRegistroAlimento: data,
        }),
      });

      if (response.ok) {
        Alert.alert("Sucesso", "Alimento adicionado com sucesso!");
        navigation.goBack();
      } else {
        const errorText = await response.text();
        console.error("Erro ao cadastrar:", errorText);
        Alert.alert("Erro", "Falha ao cadastrar alimento.");
      }
    } catch (error) {
      console.error("Erro de requisição:", error);
      Alert.alert("Erro", "Não foi possível conectar ao servidor.");
    }
  };

  return (
    <View style={styles.container}>
      <View style = {styles.formBox}>
      <Text style={styles.title}>🍽️ Adicionar Alimento</Text>
        <Text style={styles.subtitle}>
                <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                    <Text style = {styles.link}>Menu pricipal</Text> 
                </TouchableOpacity >
                {" > "}
                <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                    <Text style = {styles.link}>Menu animal</Text> 
                </TouchableOpacity >
                {" > "}
                <TouchableOpacity>
                    <Text style = {styles.link}>Vacincação</Text> 
                </TouchableOpacity >
            </Text>

      <TextInput
        placeholder="Quantidade de ração (kg)"
        style={styles.input}
        keyboardType="numeric"
        value={quantidadeRacao}
        onChangeText={setQuantidadeRacao}
      />

      <TextInput
        placeholder="Quantidade de agua (L)"
        style={styles.input}
        keyboardType="numeric"
        value={quantidadeAgua}
        onChangeText={setQuantidadeAgua}
      />

      <TextInput
        placeholder="Data de fornecimento (YYYY-MM-DD)"
        style={styles.input}
        value={data}
        onChangeText={setData}
      />

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Salvar</Text>
      </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f8f9fa",
    alignItems: "center",
  },
  formBox: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    width: "95%",
    maxWidth: 600,
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 4
    },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
    marginTop: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#198754",
  },
  input: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#ccc",
  },
  button: {
    backgroundColor: "#198754",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  subtitle: {
      color: "#6c757d",
      marginBottom: 20,
  },
  link:{

  },
});
