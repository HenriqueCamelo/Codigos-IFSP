import React, {useState} from "react";
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native";
import { RootStackParamList } from '../../App'; 
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';

type AddAlimentoRouteProp = RouteProp<RootStackParamList, "Vacina">;
type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function VacinaForm(){
    
    const route = useRoute<AddAlimentoRouteProp>();
    const navigation = useNavigation<NavigationProp>();
    
    console.log("🟢 Parâmetros recebidos:", route.params);

    const { idAnimal } = route.params || {};

    if (!idAnimal) {
        console.warn("⚠️ Nenhum ID de animal foi recebido!");
    }

    const [dataVacina, setDataVacina] = useState("");
    const [nomeVacina, setNomeVacina] = useState("");

    const handleSubmit = async () => {
       if (!dataVacina || !nomeVacina ) {
            Alert.alert("Erro", "Preencha todos os campos!");
            return;
        }

        try {
            const token = localStorage.getItem("token");
            console.log("📤 Enviando alimento para animal ID:", idAnimal);
    
            const response = await fetch(`http://localhost:8080/api/vacinas/animal/${idAnimal}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
                dataVacina: dataVacina,
                nomeVacina: nomeVacina,
                
            }),
            });
    
            if (response.ok) {
            Alert.alert("Sucesso", "Alimento adicionado com sucesso!");
            navigation.goBack();
            } else {
            const errorText = await response.text();
            console.error("Erro ao cadastrar:", errorText);
            Alert.alert("Erro", "Falha ao cadastrar alimento.");
            }
        } catch (error) {
            console.error("Erro de requisição:", error);
            Alert.alert("Erro", "Não foi possível conectar ao servidor.");
        }
    }

    const handleReset = () =>{
        const [dataVacina, setDataVacina] = useState("");
        const [nomeVacina, setNomeVacina] = useState("");
    }

    return(
        //<SafeAreaView style={{ flex: 1, backgroundColor: "#f8f9fa" }}>
            <ScrollView contentContainerStyle = {styles.container}>
                <View style = {styles.formBox}>
                    <Text style = {styles.title}>Vacinação</Text>
                        <Text style={styles.subtitle}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Vacincação</Text> 
                            </TouchableOpacity >
                        </Text>
                    

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data da aplicação:</Text>
                            <TextInput 
                                style={styles.input}
                                value={dataVacina}
                                onChangeText={setDataVacina}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>


                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Nome da vacina:</Text>
                            <TextInput 
                                style={styles.input}
                                value={nomeVacina}
                                onChangeText={setNomeVacina}
                                placeholder="Insira o nome da vacina aplicada"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>



                    <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSubmit}>
                        <Text style={styles.buttonText}>Salvar</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.button, styles.cancel]} onPress={handleReset}>
                        <Text style={styles.buttonText}>Cancelar</Text>
                    </TouchableOpacity>

                </View>
            </ScrollView>
        //</SafeAreaView>
    );
}

const styles = StyleSheet.create({
    link:{

    },
    container: {
        flexGrow: 1,
        alignItems: "center",
        padding: 20,
        backgroundColor: "#ebebebff",
    },
    formBox: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "95%",
        maxWidth: 600,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 4,
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        marginBottom: 20,
    },
    inputGroup: {
        marginBottom: 12,
    },
    label: {
        fontSize: 16,
        marginBottom: 4,
    },
    input: {
        backgroundColor: "#f8f9fa",
        borderWidth: 1,
        borderColor: "#ced4da",
        borderRadius: 6,
        padding: 10,
    },
    button: {
        width: "90%",
        alignSelf: "center",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginVertical: 6,
    },
    save: {
        backgroundColor: "#198754",
    },
    cancel: {
        backgroundColor: "#dc3545",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    }
})