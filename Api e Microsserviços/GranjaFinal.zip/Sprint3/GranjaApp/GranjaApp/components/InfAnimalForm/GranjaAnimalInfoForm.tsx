import React, { useEffect, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

type Animal = {
  id: number;
  nomeAnimal: string;
  sexoAnimal: string;
  dataNascimentoAnimal: string;
  fazenda: string;
  granja: string;
  paiAnimal: string;
  maeAnimal: string;
  vendedor: string;
  precoAnimal: number;
  dataCompra: string;
  dadosExtra: string;
};

export default function GranjaAnimalInfoForm() {
  const navigation = useNavigation<NavigationProp>();
  const [animais, setAnimais] = useState<Animal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnimais = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await fetch("http://localhost:8080/api/animals", {
          headers: { Authorization: `Bearer ${token}` },
        });

        const data = await response.json();
        console.log("Teste API:", data);

        setAnimais(data.content || []);
      } catch (error) {
        console.error("Erro ao carregar animais:", error);
      } finally {
        setLoading(false); // ✅ finaliza o carregamento
      }
    };

    fetchAnimais();
  }, []);

  const calcularIdade = (dataNascimento: string) => {
    const nascimento = new Date(dataNascimento);
    const agora = new Date();
    const diffDias = (agora.getTime() - nascimento.getTime()) / (1000 * 3600 * 24);
    const semanas = Math.floor(diffDias / 7);
    const anos = (diffDias / 365.25).toFixed(1);
    return `${semanas} semanas (${anos} anos)`;
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#198754" />
        <Text>Carregando animais...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}> Informações dos Animais</Text>
        <Text style={styles.subtitle}>

                        {" <= "}
                        <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                            <Text >Voltar</Text> 
                        </TouchableOpacity >

                    </Text>

      {animais.map((animal) => (
          
        <View key={animal.id ?? Math.random().toString()} style={styles.card}>
          <Text style={styles.animalTitle}>{animal.nomeAnimal}</Text>
          <Text>Sexo: {animal.sexoAnimal}</Text>
          <Text>Data Nascimento: {animal.dataNascimentoAnimal}</Text>
          <Text>Idade: {calcularIdade(animal.dataNascimentoAnimal)}</Text>
          <Text>Fazenda: {animal.fazenda}</Text>
          <Text>Granja: {animal.granja}</Text>
          <Text>Pai: {animal.paiAnimal}</Text>
          <Text>Mãe: {animal.maeAnimal}</Text>
          <Text>Vendedor: {animal.vendedor}</Text>
          <Text>Preço: R$ {animal.precoAnimal}</Text>
          <Text>Data Compra: {animal.dataCompra}</Text>
          <Text>Dados Extras: {animal.dadosExtra}</Text>

          <TouchableOpacity
            style={[styles.button, styles.edit]}
            onPress={() => navigation.navigate("EditarAnimal", { idAnimal: animal.id })}
          >
            <Text style={styles.buttonText}>Editar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.add]}
            onPress={() => navigation.navigate("AddAlimento", { idAnimal: animal.id })}
          >
            <Text style={styles.buttonText}>Adicionar Alimento</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.add]}
            onPress={() => navigation.navigate("Peso", { idAnimal: animal.id })}
          >
            <Text style={styles.buttonText}>Adicionar Peso</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.add]}
            onPress={() => navigation.navigate("Vacina", { idAnimal: animal.id })}
          >
            <Text style={styles.buttonText}>Adicionar Vacinação</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.delete]}
            onPress={() => navigation.navigate("AnimalDespache", { idAnimal: animal.id })}
          >
            <Text style={styles.buttonText}>Despachar</Text>
          </TouchableOpacity>
        </View>
      ))}

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
    backgroundColor: "#f8f9fa",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#198754",
    marginBottom: 15,
    textAlign: "center",
  },
  subtitle: {
    color: "#6c757d",
    marginBottom: 20,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  animalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 8,
  },
  button: {
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 6,
  },
  edit: {
    backgroundColor: "#0d6efd",
  },
  delete: {
    backgroundColor: "#dc3545",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  add: {
  backgroundColor: "#198754",
},
});
