import React, {useState} from "react";
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native";
import { RootStackParamList } from '../../App'; 
import { useNavigation } from '@react-navigation/native';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function AddAnimalForm(){
    
    const navigation = useNavigation<NavigationProp>();
    
    const [animal, setAnimal] = useState({
        nome: "",
        sexo: "",
        dataNascimento: "",
        fazenda: "",
        granja: "",
        pai: "",
        mae: "",
        vendedor: "",
        preco: "",
        dataCompra: "",
        dadosExtra: "",
    });

    const handleChange = (field: string, value: string) => {
        setAnimal({...animal, [field]: value});
    };

    const handleSubmit = async () => {
    try {
            
            if (!animal.nome || !animal.sexo || !animal.dataNascimento) {
            Alert.alert("Erro", "Preencha os campos obrigatórios!");
            return;
            }

            
            console.log("Dados enviados:", animal);

            const response = await fetch("http://localhost:8080/api/animals", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                nomeAnimal: animal.nome,
                sexoAnimal: animal.sexo,
                dataNascimentoAnimal: animal.dataNascimento,
                fazenda: animal.fazenda,
                granja: animal.granja,
                paiAnimal: animal.pai,
                maeAnimal: animal.mae,
                vendedor: animal.vendedor,
                precoAnimal: parseFloat(animal.preco),
                dataCompra: animal.dataCompra,
                dadosExtra: animal.dadosExtra,
            }),
            });

            if (response.ok) {
            Alert.alert(" Sucesso", "Animal cadastrado com sucesso!");
            handleReset(); 
            } else {
            const errorText = await response.text();
            console.error("Erro na resposta:", errorText);
            Alert.alert(" Erro", "Falha ao cadastrar animal no servidor.");
            }
        } catch (error: unknown) {
            console.error("Erro ao cadastrar animal:", error);
            Alert.alert(" Erro", "Não foi possível conectar ao servidor.");
        }
    };

    const handleReset = () =>{
        setAnimal({
            nome: "",
            sexo: "",
            dataNascimento: "",
            fazenda: "",
            granja: "",
            pai: "",
            mae: "",
            vendedor: "",
            preco: "",
            dataCompra: "",
            dadosExtra: "",
        })
    }

    return(
        //<SafeAreaView style={{ flex: 1, backgroundColor: "#f8f9fa" }}>
            <ScrollView contentContainerStyle = {styles.container}>
                <View style = {styles.formBox}>
                    <Text style = {styles.title}>Cadastro de Animais</Text>
                        <Text style={styles.subtitle}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Cadastro Animal</Text> 
                            </TouchableOpacity >
                        </Text>
                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Nome:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.nome}
                                onChangeText={(t) => handleChange("nome", t)}
                                placeholder="Insira o nome do animal"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Sexo:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.sexo}
                                onChangeText={(t) => handleChange("sexo", t)}
                                placeholder="Macho / Fêmea"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data de Nascimento:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.dataNascimento}
                                onChangeText={(t) => handleChange("dataNascimento", t)}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Fazenda:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.fazenda}
                                onChangeText={(t) => handleChange("fazenda", t)}
                                placeholder="Insira o nome da fazenda"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Granja:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.granja}
                                onChangeText={(t) => handleChange("granja", t)}
                                placeholder="Insira o nome da granja"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Pai:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.pai}
                                onChangeText={(t) => handleChange("pai", t)}
                                placeholder="Insira o pai do animal"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Mãe:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.mae}
                                onChangeText={(t) => handleChange("mae", t)}
                                placeholder="Insira o mãe do animal"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Vendedor:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.vendedor}
                                onChangeText={(t) => handleChange("vendedor", t)}
                                placeholder="Insira o vendedor"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Preço:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.preco}
                                keyboardType="numeric"
                                onChangeText={(t) => handleChange("preco", t)}
                                placeholder="Insira o preco"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data da Compra:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.dataCompra}
                                onChangeText={(t) => handleChange("dataCompra", t)}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Dados Extra:</Text>
                            <TextInput 
                                style={styles.input}
                                value={animal.dadosExtra}
                                onChangeText={(t) => handleChange("dadosExtra", t)}
                                placeholder="Insira dados extras"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSubmit}>
                        <Text style={styles.buttonText}>Salvar</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.button, styles.cancel]} onPress={handleReset}>
                        <Text style={styles.buttonText}>Cancelar</Text>
                    </TouchableOpacity>

                </View>
            </ScrollView>
        //</SafeAreaView>
    );
}

const styles = StyleSheet.create({
    link:{

    },
    container: {
        flexGrow: 1,
        alignItems: "center",
        padding: 20,
        backgroundColor: "#ebebebff",
    },
    formBox: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "95%",
        maxWidth: 600,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 4,
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        marginBottom: 20,
    },
    inputGroup: {
        marginBottom: 12,
    },
    label: {
        fontSize: 16,
        marginBottom: 4,
    },
    input: {
        backgroundColor: "#f8f9fa",
        borderWidth: 1,
        borderColor: "#ced4da",
        borderRadius: 6,
        padding: 10,
    },
    button: {
        width: "90%",
        alignSelf: "center",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginVertical: 6,
    },
    save: {
        backgroundColor: "#198754",
    },
    cancel: {
        backgroundColor: "#dc3545",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    }
})