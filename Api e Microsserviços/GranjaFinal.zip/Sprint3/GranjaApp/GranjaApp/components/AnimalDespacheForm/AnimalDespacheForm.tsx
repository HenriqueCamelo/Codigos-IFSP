import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type RouteParams = { idAnimal: number };

export default function AnimalDespacheForm() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute();
  const { idAnimal } = route.params as RouteParams;

  const [motivo, setMotivo] = useState("");
  const [loading, setLoading] = useState(false);

  const handleDespachar = async () => {
    if (!motivo.trim()) {
      Alert.alert("Aviso", "Informe o motivo do despache antes de confirmar.");
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`http://localhost:8080/api/animals/${idAnimal}?motivo=${encodeURIComponent(motivo)}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        Alert.alert("Sucesso", "Animal despachado com sucesso!");
        navigation.navigate("MenuAnimais");
      } else {
        const errorData = await response.json();
        console.error("Erro ao despachar:", errorData);
        Alert.alert("Erro", errorData.error || "Falha ao despachar o animal.");
      }
    } catch (error) {
      console.error("Erro:", error);
      Alert.alert("Erro", "Não foi possível conectar ao servidor.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Despachar Animal</Text>
      <Text style={styles.label}>Motivo do Despache</Text>
      <TextInput
        style={styles.input}
        placeholder="Ex: Animal vendido, doente, abatido..."
        value={motivo}
        onChangeText={setMotivo}
      />

      {loading ? (
        <ActivityIndicator size="large" color="#198754" />
      ) : (
        <>
          <TouchableOpacity style={[styles.button, styles.confirm]} onPress={handleDespachar}>
            <Text style={styles.buttonText}>Confirmar Despache</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.button, styles.cancel]} onPress={() => navigation.goBack()}>
            <Text style={styles.buttonText}>Cancelar</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
    padding: 20,
    justifyContent: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    color: "#198754",
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: "#333",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginBottom: 20,
    backgroundColor: "#fff",
  },
  button: {
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 10,
  },
  confirm: {
    backgroundColor: "#198754",
  },
  cancel: {
    backgroundColor: "#6c757d",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});
