import api from './api';

export async function createDespesa(data: any) {
  try {
    const response = await api.post('/api/despesas', data);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao enviar despesa:', error.response?.data || error.message);
    throw error;
  }
}