import api from './api';

export async function addAlimento(data: any) {
  try {
    const response = await api.post('/api/alimentos', data);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao enviar alimento:', error.response?.data || error.message);
    throw error;
  }
}