import api from './api';

export async function createAnimal(data: any) {
  try {
    const response = await api.post('/api/animals', data);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao enviar animal:', error.response?.data || error.message);
    throw error;
  }
}