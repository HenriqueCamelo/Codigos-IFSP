import axios from "axios";

const api = axios.create({
    //baseURL: "http://10.0.2.2:8080/api", // ✅ Para emulador Android
    baseURL: "http://localhost:8080/api", // ✅ Para navegador Web
});

export default api;