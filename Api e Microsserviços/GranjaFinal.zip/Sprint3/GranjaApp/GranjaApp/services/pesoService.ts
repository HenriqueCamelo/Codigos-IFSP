import api from './api';

export async function addPeso(data: any) {
  try {
    const response = await api.post('/api/pesos', data);
    return response.data;
  } catch (error: any) {
    console.error('Erro ao enviar peso:', error.response?.data || error.message);
    throw error;
  }
}