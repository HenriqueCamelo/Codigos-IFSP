import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import DespesasForm from '../components/DespesasForm/DespesasForm';

export default function AddDespesaScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <DespesasForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})