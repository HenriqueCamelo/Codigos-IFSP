import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import AddAnimalForm from '../components/AddAnimalForm/AddAnimalForm';

export default function AddAnimalScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <AddAnimalForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})