import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import MenuForm from '../components/MenuForm/MenuForm';

export default function MenuScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <MenuForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})