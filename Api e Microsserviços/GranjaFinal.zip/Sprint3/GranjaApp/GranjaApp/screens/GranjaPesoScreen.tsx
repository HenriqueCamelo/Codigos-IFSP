import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import PesoForm from '../components/PesoForm/PesoForm';

export default function AddPesoScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <PesoForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})