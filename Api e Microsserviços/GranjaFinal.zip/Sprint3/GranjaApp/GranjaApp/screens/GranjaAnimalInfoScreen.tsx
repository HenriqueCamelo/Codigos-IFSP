import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import GranjaAnimalInfoForm from '../components/InfAnimalForm/GranjaAnimalInfoForm';

export default function AddAnimalScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <GranjaAnimalInfoForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})