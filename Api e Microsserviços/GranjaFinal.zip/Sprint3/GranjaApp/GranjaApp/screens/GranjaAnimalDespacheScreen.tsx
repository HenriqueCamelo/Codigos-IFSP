import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import DespacheForm from '../components/AnimalDespacheForm/AnimalDespacheForm';

export default function AddAlimentoScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <DespacheForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})