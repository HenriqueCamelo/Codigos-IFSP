import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import AlimentoForm from '../components/AlimentoForm/AlimentoForm';

export default function AddAlimentoScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <AlimentoForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})