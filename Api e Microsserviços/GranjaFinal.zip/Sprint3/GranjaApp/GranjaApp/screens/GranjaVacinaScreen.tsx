import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text, ScrollView } from 'react-native';

import VacinaForm from '../components/VacinaForm/VacinaForm';

export default function AddVacinaScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <VacinaForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})