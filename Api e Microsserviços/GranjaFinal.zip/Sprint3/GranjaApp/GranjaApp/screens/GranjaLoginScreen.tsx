import React, { useState } from 'react';
import { View } from 'react-native';
import { StyleSheet, Text } from 'react-native';

import LoginForm from '../components/LoginForm/LoginForm';


export default function LoginScreen() {

    return(
        <View style = {styles.view}>
            <LoginForm/>
        </View>
    );
}

const styles = StyleSheet.create({
  view: {
    flex: 1,
    justifyContent: 'center', 
    alignItems: 'center',    
  },
})