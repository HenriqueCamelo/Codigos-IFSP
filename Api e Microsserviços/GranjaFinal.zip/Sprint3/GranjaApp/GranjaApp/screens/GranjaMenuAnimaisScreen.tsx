import React from 'react';
import { StyleSheet, ScrollView } from 'react-native';

import MenuAnimaisForm from '../components/MenuAnimais/MenuAnimaisForm';

export default function MenuAnimaisScreen() {

    return(
        <ScrollView contentContainerStyle={styles.container}>
            <MenuAnimaisForm/>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', 
        
  },
})