INSERT INTO users (username, email, password)
VALUES 
('user1', 'user1@example.com', '$2a$10$Dn9PZOlmr1F4PXHcFJYEXOdvU0X2kQ9qXxHnFS2K7l5hBgldO4SUO'),
('admin', 'admin@example.com', '$2a$10$Dn9PZOlmr1F4PXHcFJYEXOdvU0X2kQ9qXxHnFS2K7l5hBgldO4SUO'),
('user2', 'user2@example.com', '$2a$10$Dn9PZOlmr1F4PXHcFJYEXOdvU0X2kQ9qXxHnFS2K7l5hBgldO4SUO'),
('user3', 'user3@example.com', '$2a$10$Dn9PZOlmr1F4PXHcFJYEXOdvU0X2kQ9qXxHnFS2K7l5hBgldO4SUO');


-- Atribuir roles aos usuários
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, role r
WHERE u.username = 'user1' AND r.role_name = 'USER';

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, role r
WHERE u.username = 'admin' AND r.role_name = 'ADMIN';

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, role r
WHERE u.username = 'user2' AND r.role_name = 'USER';

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, role r
WHERE u.username = 'user3' AND r.role_name = 'USER';