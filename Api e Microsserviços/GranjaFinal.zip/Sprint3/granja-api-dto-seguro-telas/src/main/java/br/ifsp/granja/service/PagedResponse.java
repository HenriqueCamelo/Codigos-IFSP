package br.ifsp.granja.service;

public class PagedResponse {
    
}
