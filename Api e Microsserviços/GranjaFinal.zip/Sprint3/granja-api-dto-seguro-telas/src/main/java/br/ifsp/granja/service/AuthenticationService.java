package br.ifsp.granja.service;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import br.ifsp.granja.model.User;
import br.ifsp.granja.repository.UserRepository;

@Service
public class AuthenticationService {

    private final JwtService jwtService;
    private final UserRepository userRepository;
    //private final AuthenticationManager authenticationManager;

    public AuthenticationService(JwtService jwtService, 
                                 UserRepository userRepository/* , 
                                 AuthenticationManager authenticationManager */) {
        this.jwtService = jwtService;
        this.userRepository = userRepository;
        //this.authenticationManager = authenticationManager;
    }

    public String authenticate(Authentication authentication) {


        // 🔹 Busca o usuário
        String username = authentication.getName();
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // 🔹 Gera o token JWT
        return jwtService.generateToken(user);
    }
}
