package br.ifsp.granja.model.enumeration;

public enum ERole {
    USER,
    ADMIN
}
