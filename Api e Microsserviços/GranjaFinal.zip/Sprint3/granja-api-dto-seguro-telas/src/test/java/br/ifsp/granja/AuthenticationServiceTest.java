package br.ifsp.granja;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;

import br.ifsp.granja.model.User;
import br.ifsp.granja.repository.UserRepository;
import br.ifsp.granja.service.AuthenticationService;
import br.ifsp.granja.service.JwtService;

class AuthenticationServiceTest {

    @Mock
    private JwtService jwtService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private AuthenticationService authenticationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void deveGerarTokenQuandoUsuarioExistir() {
        // Arrange
        User user = new User();
        user.setUsername("henrique");

        when(authentication.getName()).thenReturn("henrique");
        when(userRepository.findByUsername("henrique")).thenReturn(Optional.of(user));
        when(jwtService.generateToken(user)).thenReturn("fake-jwt-token");

        // Act
        String token = authenticationService.authenticate(authentication);

        // Assert
        assertEquals("fake-jwt-token", token);
        verify(userRepository).findByUsername("henrique");
        verify(jwtService).generateToken(user);
    }

    @Test
    void deveLancarExcecaoQuandoUsuarioNaoExistir() {
        // Arrange
        when(authentication.getName()).thenReturn("naoexiste");
        when(userRepository.findByUsername("naoexiste")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> authenticationService.authenticate(authentication));

        assertEquals("User not found", exception.getMessage());
    }
}
