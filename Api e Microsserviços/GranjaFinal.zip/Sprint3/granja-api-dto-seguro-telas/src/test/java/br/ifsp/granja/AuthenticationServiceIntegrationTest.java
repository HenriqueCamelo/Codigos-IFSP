package br.ifsp.granja;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.transaction.annotation.Transactional;

import br.ifsp.granja.model.User;
import br.ifsp.granja.repository.UserRepository;
import br.ifsp.granja.service.AuthenticationService;
import br.ifsp.granja.service.JwtService;

@SpringBootTest
@Transactional
class AuthenticationServiceIntegrationTest {

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtService;

    @Test
    void deveGerarTokenQuandoUsuarioExistir() {
        // Arrange
        User user = new User();
        user.setUsername("henrique");
        user.setPassword("123456");
        userRepository.save(user);

        var authentication = new TestingAuthenticationToken("henrique", null);

        // Act
        String token = authenticationService.authenticate(authentication);

        // Assert
        assertNotNull(token);
        assertTrue(token.startsWith("ey")); 
    }

    @Test
    void deveLancarExcecaoQuandoUsuarioNaoExistir() {
        var authentication = new TestingAuthenticationToken("usuario_invalido", null);

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                authenticationService.authenticate(authentication)
        );

        assertEquals("User not found", ex.getMessage());
    }
}
