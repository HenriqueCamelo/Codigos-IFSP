DROP DATABASE  IF EXISTS `vcriquinho`;
CREATE DATABASE  IF NOT EXISTS `vcriquinho`;

USE `vcriquinho`;

DROP TABLE IF EXISTS `cliente`;
create table `cliente` (
	`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`nome` varchar(100),
    `email` varchar(100),
    `tipo_cliente` varchar(2) check (tipo_cliente in ('PF', 'PJ')),
    `documento` VARCHAR(20) UNIQUE NOT NULL
);

DROP TABLE IF EXISTS `conta`;
create table `conta` (
	`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`cliente_id` INT NOT NULL,
    `saldo` DECIMAL(15,2) default 0.0,
    `tipo_conta` varchar(30) check (tipo_conta in ('Corrente', 'CDI','Investimento Automático')),
    `taxa_servico` DECIMAL(5,4),
    FOREIGN KEY (cliente_id) REFERENCES cliente(id) ON DELETE CASCADE
);

DROP TABLE IF EXISTS `produto_investimento`;
create table `produto_investimento` (
	`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`nome` varchar(100) NOT NULL,
    `rendimento_mensal` DECIMAL(5,4) NOT NULL,
    `tipo_produto` varchar(20) check (tipo_produto IN ('Renda Fixa', 'Renda Variavel')),
    `periodo_carencia` INT DEFAULT 0
);

DROP TABLE IF EXISTS `conta_Produto`;
create table `conta_Produto` (
	`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`conta_id` INT NOT NULL,
    `produto_id` INT NOT NULL,
    `valor_investido` DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (conta_id) REFERENCES conta(id) ON DELETE CASCADE,
    FOREIGN KEY (produto_id) REFERENCES produto_Investimento(id) ON DELETE CASCADE

);

DROP TABLE IF EXISTS `transacao`;
create table `transacao` (
	`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`conta_id` INT NOT NULL,
    `tipo` VARCHAR(10) CHECK (tipo IN ('Deposito', 'Resgate')),
    `valor` DECIMAL(15,2) NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conta_id) REFERENCES conta(id) ON DELETE CASCADE

);

INSERT INTO Cliente (nome, email, tipo_cliente, documento)
VALUES ('João Silva', 'joao@email.com', 'PF', '123.456.789-00');

INSERT INTO Conta (cliente_id, tipo_conta, saldo, taxa_servico)
VALUES (1, 'Investimento Automático', 10000.00, 0.1);

INSERT INTO Produto_Investimento (nome, tipo_produto, rendimento_mensal, periodo_carencia)
VALUES ('Tesouro Selic', 'Renda Fixa', 0.005, 30);

INSERT INTO Conta_Produto (conta_id, produto_id, valor_investido)
VALUES (1, 1, 5000.00);

INSERT INTO Transacao (conta_id, tipo, valor)
VALUES (1, 'Depósito', 5000.00);