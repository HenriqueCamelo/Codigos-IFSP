import * as React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

import { SafeAreaProvider } from 'react-native-safe-area-context';

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';

import LoginScreen from './screens/GranjaLoginScreen';
import MenuScreen from './screens/GranjaMenuScreen';
import AddAnimal from './screens/GranjaAddAnimalScreen';
import MenuAnimaisScreen from './screens/GranjaMenuAnimaisScreen';
import PesoScreen from './screens/GranjaPesoScreen'
import VacinaScreen from './screens/GranjaVacinaScreen'
import AlimentoScreen from './screens/GranjaAlimentoScreen'
import DespesaScreen from './screens/GranjaAddDespesaScreen'

//const Stack  = createNativeStackNavigator();

/* function MyDrawer() {
  return(
    <Stack.Navigator initialRouteName = "Login" screenOptions={{ headerShown: false }}>
      <Stack.Screen name = "Login" component={LoginScreen}/>
      <Stack.Screen name = "Menu" component={MenuScreen}/>
    </Stack.Navigator>
  );
} */

export type RootStackParamList = {
  Login: undefined;
  Menu: undefined;
  AdicionarAnimal: undefined;
  MenuAnimais: undefined;
  Peso: undefined;
  Vacina: undefined;
  Alimento: undefined;
  Despesa: undefined;
};

// 👇 Agora criamos o Stack tipado
const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="AdicionarAnimal" component={AddAnimal} />
        <Stack.Screen name="MenuAnimais" component={MenuAnimaisScreen} />
        <Stack.Screen name="Peso" component={PesoScreen} />
        <Stack.Screen name="Vacina" component={VacinaScreen} />
        <Stack.Screen name="Alimento" component={AlimentoScreen} />
        <Stack.Screen name="Despesa" component={DespesaScreen} />
      </Stack.Navigator>
    </NavigationContainer>

  );
}




