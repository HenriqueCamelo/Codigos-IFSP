import React, {useState} from "react";
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native";
import { RootStackParamList } from '../../App'; 
import { useNavigation } from '@react-navigation/native';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function AddDespesasForm(){
    
    const navigation = useNavigation<NavigationProp>();
    
    const [despesa, setDespesa] = useState({
        dataCompra: "",
        endereco: "",
        cidade: "",
        bairro: "Centro",
        cpf: "",
        valor: "",
        numeroParcelas: "",
        fazenda: ""
    });

    const handleChange = (field: string, value: string) => {
        setDespesa({...despesa, [field]: value});
    };

    const handleSubmit = () => {
        Alert.alert("Cadastro", "Animal salvo com sucesso!");
    }

    const handleReset = () =>{
        setDespesa({
            dataCompra: "",
            endereco: "",
            cidade: "",
            bairro: "Centro",
            cpf: "",
            valor: "",
            numeroParcelas: "",
            fazenda: ""
        })
    }

    return(
        //<SafeAreaView style={{ flex: 1, backgroundColor: "#f8f9fa" }}>
            <ScrollView contentContainerStyle = {styles.container}>
                <View style = {styles.formBox}>
                    <Text style = {styles.title}>Cadastro de Animais</Text>
                        <Text style={styles.subtitle}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Cadastro Animal</Text> 
                            </TouchableOpacity >
                        </Text>
                    
                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data da Compra:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.dataCompra}
                                onChangeText={(t) => handleChange("dataCompra", t)}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Granja:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.endereco}
                                onChangeText={(t) => handleChange("endereco", t)}
                                placeholder="Insira o endereço"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Endereço:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.endereco}
                                onChangeText={(t) => handleChange("endereco", t)}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>


                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Cidade:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.cidade}
                                onChangeText={(t) => handleChange("cidade", t)}
                                placeholder="Insira a cidade"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Bairro:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.bairro}
                                onChangeText={(t) => handleChange("bairro", t)}
                                placeholder="Insira o bairro"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>CPF:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.cpf}
                                onChangeText={(t) => handleChange("vendedor", t)}
                                placeholder="Insira o cpf do vendedor"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Valor:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.valor}
                                keyboardType="numeric"
                                onChangeText={(t) => handleChange("valor", t)}
                                placeholder="Isira o preco"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Valor:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.numeroParcelas}
                                keyboardType="numeric"
                                onChangeText={(t) => handleChange("numeroParcelas", t)}
                                placeholder="Isira o numero de parcelas"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Bairro:</Text>
                            <TextInput 
                                style={styles.input}
                                value={despesa.fazenda}
                                onChangeText={(t) => handleChange("fazenda", t)}
                                placeholder="Insira sua fazenda"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSubmit}>
                        <Text style={styles.buttonText}>Salvar</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.button, styles.cancel]} onPress={handleReset}>
                        <Text style={styles.buttonText}>Cancelar</Text>
                    </TouchableOpacity>

                </View>
            </ScrollView>
        //</SafeAreaView>
    );
}

const styles = StyleSheet.create({
    link:{

    },
    container: {
        flexGrow: 1,
        alignItems: "center",
        padding: 20,
        backgroundColor: "#ebebebff",
    },
    formBox: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "95%",
        maxWidth: 600,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 4,
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        marginBottom: 20,
    },
    inputGroup: {
        marginBottom: 12,
    },
    label: {
        fontSize: 16,
        marginBottom: 4,
    },
    input: {
        backgroundColor: "#f8f9fa",
        borderWidth: 1,
        borderColor: "#ced4da",
        borderRadius: 6,
        padding: 10,
    },
    button: {
        width: "90%",
        alignSelf: "center",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginVertical: 6,
    },
    save: {
        backgroundColor: "#198754",
    },
    cancel: {
        backgroundColor: "#dc3545",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    }
})