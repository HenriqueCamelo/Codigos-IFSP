import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, useWindowDimensions } from "react-native";

import { useNavigation } from '@react-navigation/native';

export default function MenuAnimais(){
    const { width } = useWindowDimensions();
    const isSmallScreen = width < 1000;
    const navigation = useNavigation();
    return(
        
        <ScrollView contentContainerStyle={[
                        styles.container,
                        isSmallScreen && { flexGrow: 0 } 
                    ]}>
    
                <View style = {styles.content}>
                    {/* <Text style= {styles.sectionTitle}>Menu Animais</Text> */}
                    
                    
                    <View style={[styles.sectionTitle, isSmallScreen && { borderBottomWidth: 1, paddingHorizontal: 0}]}>
                        <Text style = {styles.title}>Cadastro de Animais</Text>
                        <Text style={[styles.subtitle, isSmallScreen && { borderBottomWidth: 0 }]}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                        </Text>
                    </View>

                <View style={[
                    styles.cardsContainer,
                    isSmallScreen && { paddingHorizontal: 0,flexDirection: "column", alignItems: "center", flexWrap: "nowrap" },
                ]}>
                    
                

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('AdicionarAnimal')}>
                    <Text style={styles.cardText}>🐓 Cadastro de franga</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('Vacina')}>
                    <Text style={styles.cardText}>💉 Vacinação</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('Peso')}>
                    <Text style={styles.cardText}>⚖ Pesagem</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]}>
                    <Text style={styles.cardText}>🗄 Informações Animais</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]}>
                    <Text style={styles.cardText}>🥚 Registro Ovos</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.card, isSmallScreen && { width: "90%" }]} onPress={ () => navigation.navigate('Alimento')}>
                    <Text style={styles.cardText}>🍽 Registro Alimentação</Text>
                </TouchableOpacity>


                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        
        backgroundColor: "#f8f9fa",
        width: "100%",
        
    },
    content: {
        padding: 20,
    },
    sectionTitle: {
        fontSize: 22,
        fontWeight: "600",
        marginBottom: 20,
        paddingBottom: 8,
        paddingHorizontal: 240,
        borderBottomWidth: 0,
        borderBottomColor: "#ccc",
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        borderBottomWidth: 1,
        borderBottomColor: "#ccc",
    },
    cardsContainer: {
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
        paddingHorizontal: 240,
    },
    card: {
        width: "48%",
        backgroundColor: "#fff",
        borderRadius: 12,
        paddingVertical: 40,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 20,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 4},
        shadowOpacity: 0.15,
        shadowRadius: 5,
        elevation: 3,
    },
    cardText: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#333",
    }
})