import React, {useState} from "react";
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native";
import { RootStackParamList } from '../../App'; 
import { useNavigation } from '@react-navigation/native';

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function AddAnimalForm(){
    
    const navigation = useNavigation<NavigationProp>();
    
    const [alimento, setAlimento] = useState({
        dataRegistroAlimento: "",
        quantidadeAgua: "",
        quantidadeRacao: "",
    });

    const handleChange = (field: string, value: string) => {
        setAlimento({...alimento, [field]: value});
    };

    const handleSubmit = () => {
        Alert.alert("Cadastro", "Pesagem salva com sucesso!");
    }

    const handleReset = () =>{
        setAlimento({
            dataRegistroAlimento: "",
            quantidadeAgua: "",
            quantidadeRacao: "",
        })
    }

    return(
        //<SafeAreaView style={{ flex: 1, backgroundColor: "#f8f9fa" }}>
            <ScrollView contentContainerStyle = {styles.container}>
                <View style = {styles.formBox}>
                    <Text style = {styles.title}>Alimento</Text>
                        <Text style={styles.subtitle}>
                            <TouchableOpacity onPress={ () => navigation.navigate('Menu')}>
                                <Text style = {styles.link}>Menu pricipal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity onPress={ () => navigation.navigate('MenuAnimais')}>
                                <Text style = {styles.link}>Menu animal</Text> 
                            </TouchableOpacity >
                            {" > "}
                            <TouchableOpacity>
                                <Text style = {styles.link}>Alimeto</Text> 
                            </TouchableOpacity >
                        </Text>
                    

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Data da alimetação:</Text>
                            <TextInput 
                                style={styles.input}
                                value={alimento.dataRegistroAlimento}
                                onChangeText={(t) => handleChange("dataRegistroAlimento", t)}
                                placeholder="AAAA-MM-DD"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>


                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Quantidade de água:</Text>
                            <TextInput 
                                style={styles.input}
                                value={alimento.quantidadeAgua}
                                keyboardType="numeric"
                                onChangeText={(t) => handleChange("quantidadeAgua", t)}
                                placeholder="Insira a quantidade de água"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>

                    <View style={styles.inputGroup}>
                        <View>
                            <Text style={styles.label}>Quantidade de ração:</Text>
                            <TextInput 
                                style={styles.input}
                                value={alimento.quantidadeRacao}
                                keyboardType="numeric"
                                onChangeText={(t) => handleChange("quantidadeRacao", t)}
                                placeholder="Insira quantidade de ração"
                                placeholderTextColor="#6e6e6eff"
                            />
                        </View>
                    </View>



                    <TouchableOpacity style={[styles.button, styles.save]} onPress={handleSubmit}>
                        <Text style={styles.buttonText}>Salvar</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.button, styles.cancel]} onPress={handleReset}>
                        <Text style={styles.buttonText}>Cancelar</Text>
                    </TouchableOpacity>

                </View>
            </ScrollView>
        //</SafeAreaView>
    );
}

const styles = StyleSheet.create({
    link:{

    },
    container: {
        flexGrow: 1,
        alignItems: "center",
        padding: 20,
        backgroundColor: "#ebebebff",
    },
    formBox: {
        backgroundColor: "#fff",
        padding: 20,
        borderRadius: 10,
        width: "95%",
        maxWidth: 600,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowOpacity: 0.15,
        shadowRadius: 8,
        elevation: 4,
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#198754",
        marginBottom: 5,
    },
    subtitle: {
        color: "#6c757d",
        marginBottom: 20,
    },
    inputGroup: {
        marginBottom: 12,
    },
    label: {
        fontSize: 16,
        marginBottom: 4,
    },
    input: {
        backgroundColor: "#f8f9fa",
        borderWidth: 1,
        borderColor: "#ced4da",
        borderRadius: 6,
        padding: 10,
    },
    button: {
        width: "90%",
        alignSelf: "center",
        padding: 12,
        borderRadius: 8,
        alignItems: "center",
        marginVertical: 6,
    },
    save: {
        backgroundColor: "#198754",
    },
    cancel: {
        backgroundColor: "#dc3545",
    },
    buttonText: {
        color: "#fff",
        fontWeight: "bold",
        fontSize: 16,
    }
})