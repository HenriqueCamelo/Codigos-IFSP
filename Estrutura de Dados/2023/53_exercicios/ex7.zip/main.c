#include <stdio.h>

float num1;
float conversão;
float dolar = 4.73;

int main()
{
    printf("Escreva o valor em reais a ser convertido: \n"); 
    scanf("%f", &num1);
   
   conversão = num1*4.73;
    
    printf("\n\nO valor em dólares aproximadamete é: %.1f reais", conversão); 
}   