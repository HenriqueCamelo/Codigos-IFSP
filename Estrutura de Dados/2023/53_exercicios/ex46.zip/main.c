#include <stdio.h>

int main()
{
    float Kg, libras;
    
    printf("Digite a massa em quilogramas que será convertida em líbras: ");
    scanf("%f", &Kg);
    
    libras = Kg/0.45;

    printf("A massa em libras é: %.2f", libras);

    return 0;
}
