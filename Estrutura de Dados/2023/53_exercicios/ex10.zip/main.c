#include <stdio.h>

int num1;
int area;



int main()
{
    printf("Escreva o comprimento do lado de seu quadrado: \n"); 
    scanf("%d", &num1);
   
    area = num1 * num1;
    
    printf("\n\nA área do quadrado é: %d", area); 
}   
