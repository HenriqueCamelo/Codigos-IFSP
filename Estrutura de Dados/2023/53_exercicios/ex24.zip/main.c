#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numero1 = 1 , numero2 = 2, numero3 = 3, numero4 = 4;


int main()
{
    if(numero1<10 && numero2<10 && numero3<10 && numero4<10)
    {
    printf("Digite um número de três digitos: ");
    scanf("%d%d%d%d", &numero1, &numero2, &numero3, &numero4);
    
    printf("\n\n\n%d\n%d\n%d\n%d\n", numero1, numero2, numero3, numero4);
    }
    else
    {
        printf("Número inválido");
    }
   
    
    return 0;
}