#include <stdio.h>

int main()
{
    float metros2, acres;
    
    printf("Digite a área em metros quadrados que será convertida em acres: ");
    scanf("%f", &metros2);
    
    acres = metros2*0.000247;
   
    printf("A área em acres é: %.6f", acres);

    return 0;
}
