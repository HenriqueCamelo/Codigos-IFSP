#include <stdio.h>


float num1;
float des, parc, vend;



int main()
{
    printf("Digite o valor do produto: ");
    scanf("%f", &num1);
    
    des = num1 - num1*0.10;
    parc = num1/3;
    vend = des*0.05;
    
    printf("O preço a ser pago a vista é %.2f \n", des);
    printf("O preço a ser pago por parcela é %.2f \n", parc);
    printf("O vendedor receberá %.2f \n", vend);
    
}  