#include <stdio.h>

int main()
{
    float graus, radianos;
    
    printf("Digite o ângulo em graus que será convertida em radianos: ");
    scanf("%f", &graus);
    
    radianos = graus * 3.141592/180; 
    
    printf("O ângulo em radianos é: %.2f", radianos);

    return 0;
}