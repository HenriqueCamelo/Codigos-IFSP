#include <stdio.h>

int main()
{
    float jardas, metros;
    
    printf("Digite o comprimento em jardas que será convertida em metros: ");
    scanf("%f", &jardas);
    
    metros = 0.91*jardas;

    printf("O comprimento em metros é: %.2f", metros);

    return 0;
}
