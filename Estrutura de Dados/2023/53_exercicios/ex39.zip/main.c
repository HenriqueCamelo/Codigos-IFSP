#include <stdio.h>

int main()
{
    float km, m;
    
    printf("Digite a distância em quilômetros que será convertida em milhas: ");
    scanf("%f", &km);
    
    m = km/1.61;
    
    printf("A distância em milhas é: %.2f", m);

    return 0;
}