#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float celsius, Kelvin;

    
    printf("Digite a temperatura em Kelvin que será convertida: ");
    scanf("%f", &Kelvin);
    
    celsius = Kelvin - 273.15;
    
    printf("A temperatura em celsius é: %.2f", celsius);
    

   return 0;
}