#include <stdio.h>

int inte, intei, inteir, qua1, qua2, qua3;
int soma;

int main()
{
    printf("Escreva numero inteiro 1 : \n"); 
    scanf("%d", &inte);
    
    printf("Escreva numero inteiro 2 : \n"); 
    scanf("%d", &intei);
    
    printf("Escreva numero inteiro 3 : \n"); 
    scanf("%d", &inteir);
    
    qua1 = inte*inte;
    qua2 = intei*intei;
    qua3 = inteir*inteir;
    soma = qua1 + qua2 + qua3;
    
    printf("A soma dos quadrados destes três números inteiros é: %d", soma); 
}  
