#include <stdio.h>
#include <math.h>

float num1, num2;
float hipotenusa;
float resultado;


int main()
{
    printf("Digite o tamanho do primeiro cateto: \n"); 
    scanf("%f", &num1);
    
    printf("Digite o tamanho do segundo cateto: \n"); 
    scanf("%f", &num2);
   
    hipotenusa = sqrt((num1 * num1) + (num2 * num2));
    
    
    
    printf("\n\nA hipotenusa é: %.0f", hipotenusa); 
}   
