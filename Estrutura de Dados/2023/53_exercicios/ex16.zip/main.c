#include <stdio.h>


int total =780000;
int primeiro, segundo, terceiro;



int main()
{
    printf("O valor total é %d \n", total); 
    
    primeiro = total * 0.46;
    printf("O primeiro lugar receberá um total de %d \n", primeiro); 
   
    segundo = total * 0.32;
    printf("O segundo lugar receberá um total de %d \n", segundo); 
    
    terceiro = total * 0.22;
    printf("O terceiro lugar receberá um total de %d \n", terceiro); 
    
    
}  