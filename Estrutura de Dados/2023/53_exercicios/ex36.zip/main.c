#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float kilometro, metros;

    
    printf("Digite a velocidade em km/h que será convertida: ");
    scanf("%f", &kilometro);
    
    metros = kilometro/3.6;
    
    printf("A velocidade em m/s é: %.2f", metros);
    

   return 0;
}
