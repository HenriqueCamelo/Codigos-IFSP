#include <stdio.h>

int main()
{
    float jardas, metros;
    
    printf("Digite o comprimento em metros que será convertida em jardas: ");
    scanf("%f", &metros);
    
    jardas = metros/0.91;
   
    printf("O comprimento em jardas é: %.2f", jardas);

    return 0;
}