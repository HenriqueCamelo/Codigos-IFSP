#include <stdio.h>


float num1;
float tdias, total, imp;



int main()
{
    printf("Digite a quantidade de dias a ser trabalhadas pelo encanador: ");
    scanf("%f", &num1);
    
    tdias = (30*num1);
    imp = tdias*0.08;
    total = tdias - imp;
    
    printf("O salário a ser dado ao encanador é %.2f", total);    
}   