#include <stdio.h>
#include <stdlib.h>

int main() {

    int nota1, nota2, nota3, media, matricula;
    
    printf("Digite o número de matrícula do aluno: ");
    scanf("%d", &matricula);
    
    printf("Digite a primeira nota do aluno: ");
    scanf("%d", &nota1);
    
    printf("Digite a segunda nota do aluno: ");
    scanf("%d", &nota2);
    
    printf("Digite a terceira nota do aluno: ");
    scanf("%d", &nota3);
    
    media = ((nota1*1) + (nota2*1) + (nota3*2))/4;
    
    printf("\n\n\nO número de matrícula do aluno: %d \n", matricula);
    
    if(media < 60)
    {
        printf("O aluno foi reprovado com uma media de: %d", media);
    }
    else
    {
        printf("O aluno foi aprovado com uma media de: %d", media);
    }
   return 0;
}