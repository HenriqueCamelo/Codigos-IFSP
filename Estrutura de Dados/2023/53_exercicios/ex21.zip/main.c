#include <stdio.h>

int altura;
int ddegraus;
int totald;

int main()
{
    printf("Digite a altura do degrau que deseja subir: ");
    scanf("%d", &ddegraus);
    
    printf("Digite a altura que deseja atingir: ");
    scanf("%d", &altura);
    
    totald = altura / ddegraus;
    
    printf("O total de degraus que terá de subir será de %d", totald);
    
    return 0;
}