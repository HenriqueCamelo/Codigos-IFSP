#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float celsius, Kelvin;

    
    printf("Digite a temperatura em celsius que será convertida: ");
    scanf("%f", &celsius);
    
    Kelvin = celsius + 273.15;
    
    printf("A temperatura em Kelvin é: %.2f", Kelvin);
    

   return 0;
}