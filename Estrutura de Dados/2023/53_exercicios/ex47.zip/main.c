#include <stdio.h>

int main()
{
    float Kg, libras;
    
    printf("Digite a massa em libras que será convertida em quilogramas: ");
    scanf("%f", &libras);
    
    Kg = libras * 0.45;

    printf("A massa em quilogramas é: %.2f", Kg);

    return 0;
}