#include <stdio.h>

int main()
{
    float m3, litros;
    
    printf("Digite o volume em litros que será convertida em metros cúbicos: ");
    scanf("%f", &litros);
    
    m3 = litros/1000;

    printf("O volume em metros cúbicos é: %.2f", m3);

    return 0;
}
