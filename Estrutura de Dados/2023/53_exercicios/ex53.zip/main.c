#include <stdio.h>

int main()
{
    float metros2, hectares;
    
    printf("Digite a área em hectares que será convertida em metros quadrados: ");
    scanf("%f", &hectares);
    
    metros2 = hectares * 10000;
   
    printf("A área em metros quadrados é: %.4f", metros2);

    return 0;
}
