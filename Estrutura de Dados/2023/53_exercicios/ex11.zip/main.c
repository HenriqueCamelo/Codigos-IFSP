#include <stdio.h>

float num1;
float area;



int main()
{
    printf("Digite o raio de seu círculo: \n"); 
    scanf("%f", &num1);
   
    area = (num1 * num1) * 3.141592;
    
    printf("\n\nA área do círculo é: %.6f", area); 
}   