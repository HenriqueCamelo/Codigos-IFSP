#include <stdio.h>

int inte, intei, inteir;
int soma;

int main()
{
    printf("Escreva numero inteiro 1 : \n"); 
    scanf("%d", &inte);
    
    printf("Escreva numero inteiro 2 : \n"); 
    scanf("%d", &intei);
    
    printf("Escreva numero inteiro 3 : \n"); 
    scanf("%d", &inteir);
    
    soma = inte + intei + inteir;
    
    printf("A soma dos três números inteiros é: %d", soma); 
}   
