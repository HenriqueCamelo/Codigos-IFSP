#include <stdio.h>

int num1;
int equa;

int main()
{
    printf("Escreva um número: \n"); 
    scanf("%d", &num1);
   
    equa = num1 * 3 + 1 + num1 * 2 - 1;
    
    printf("\n\nA soma do sucessor de seu triplo com o antecessor de seu dobro é: %d", equa); 
}  
