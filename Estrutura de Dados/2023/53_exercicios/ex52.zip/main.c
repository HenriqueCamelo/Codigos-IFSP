#include <stdio.h>

int main()
{
    float metros2, hectares;
    
    printf("Digite a área em metros quadrados que será convertida em hectares: ");
    scanf("%f", &metros2);
    
    hectares = metros2 * 0.0001;
   
    printf("A área em hectares é: %.4f", hectares);

    return 0;
}
