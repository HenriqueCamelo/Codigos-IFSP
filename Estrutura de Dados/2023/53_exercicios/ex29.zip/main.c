#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float x, y, hipotenusa;
    
    printf("Digite a coordenada X: ");
    scanf("%f", &x);

    printf("Digite a coordenada Y: ");
    scanf("%f", &y);
    
    hipotenusa = sqrt((x*x)+(y*y));
    
    printf("A distância entre o ponto(0,0) ao ponto digitado é: %.1f", hipotenusa);

   return 0;
}