#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float kilometro, milhas;

    
    printf("Digite a distância em milhas: ");
    scanf("%f", &milhas);
    
    kilometro = milhas * 1.61;
    
    printf("A distância em kilometros é: %.2f", kilometro);
    

   return 0;
}