#include <stdio.h>


float num1, num2;
float sg, imp, total;



int main()
{
    printf("Digite o salário base: ");
    scanf("%f", &num1);
    
    sg = num1*0.05;
    imp = num1*0.07;
    total = num1 + sg - imp;
    
    printf("O salário é de %.2f", total);

}  