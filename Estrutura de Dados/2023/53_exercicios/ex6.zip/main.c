#include <stdio.h>

float num1, num2, num3, num4;
float media;

int main()
{
    printf("Escreva numero inteiro 1 : \n"); 
    scanf("%f", &num1);
    
    printf("Escreva numero inteiro 2 : \n"); 
    scanf("%f", &num2);
    
    printf("Escreva numero inteiro 3 : \n"); 
    scanf("%f", &num3);
    
    printf("Escreva numero inteiro 4 : \n"); 
    scanf("%f", &num4);
    
    media = (num1 + num2 + num3 + num4)/4;
    
    printf("\nA média das notas é: %.1f", media); 
}   