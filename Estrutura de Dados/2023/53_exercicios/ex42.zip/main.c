#include <stdio.h>

int main()
{
    float polegadas, centimetros;
    
    printf("Digite o comprimento em polegadas que será convertida em centímetros: ");
    scanf("%f", &polegadas);
    
    centimetros = polegadas * 2.54;
    
    printf("O comprimento em centímetros é: %.2f", centimetros);

    return 0;
}