#include <stdio.h>

int main()
{
    float polegadas, centimetros;
    
    printf("Digite o comprimento em centímetros que será convertida em polegadas: ");
    scanf("%f", &centimetros);
    
    polegadas = centimetros/2.54;
    
    printf("O comprimento em polegadas é: %.2f", polegadas);

    return 0;
}
