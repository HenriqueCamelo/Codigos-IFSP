#include <stdio.h>

float inte;
float divi;

int main()
{
    printf("Escreva numero inteiro : \n"); 
    scanf("%f", &inte);
    
    divi = inte/5;
    
    printf("A quinta parte deste número é : %.1f \n", divi); 

    
}   