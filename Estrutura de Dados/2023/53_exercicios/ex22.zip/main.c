#include <stdio.h>

char letra;


int main()
{
    printf("Digite uma letra maiúscula: ");
    scanf("%c", &letra);
    
    printf("A letra minúscula daquela que foi digitada é: %c", letra + 32);
    
    return 0;
}