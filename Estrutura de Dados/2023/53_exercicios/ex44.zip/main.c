#include <stdio.h>

int main()
{
    float m3, litros;
    
    printf("Digite o volume em metros cúbicos que será convertida em litros: ");
    scanf("%f", &m3);
    
    litros = 1000 * m3;

    printf("O volume em litros é: %.2f", litros);

    return 0;
}