#include <stdio.h>


float num1;
float preco;



int main()
{
    printf("Digite o valor da compra: \n"); 
    scanf("%f", &num1);
    
    
   
    preco = num1 - (num1*0.12);
    
    
    
    printf("\n\nO preço a ser pago é: %.2f", preco); 