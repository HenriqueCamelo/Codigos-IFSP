#include <stdio.h>

int numero1, numero2, numero3;
int temp;

int main()
{
    printf("Digite um número de três digitos: ");
    scanf("%d %d %d", &numero1, &numero2, &numero3);
    
    if(numero1<10 && numero2<10 && numero3<10)
    {
    temp = numero2;
    numero2 = numero1;
    numero1 = numero3;
    numero3 = numero2;
    numero2 = temp;
    
     printf("O novo número é %d %d %d", numero1, numero2, numero3);
        
    }
    else
    {
        printf("Número inválido");
    }
    return 0;
}
