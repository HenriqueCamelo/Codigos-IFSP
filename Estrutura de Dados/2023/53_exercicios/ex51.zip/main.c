#include <stdio.h>

int main()
{
    float metros2, acres;
    
    printf("Digite a área em acres que será convertida em metros quadrados: ");
    scanf("%f", &acres);
    
    metros2 = acres * 4048.58;
   
    printf("A área em acres é: %.2f", metros2);

    return 0;
}
