#include <stdio.h>


float num1, num2;
float tdias, total, imp;



int main()
{
    printf("Digite o quanto é ganho por hora: ");
    scanf("%f", &num1);
    
    printf("Digite o número de horas trabalhadas no mês: ");
    scanf("%f", &num2);
    
    total = (num1*num2)*1.1;
    
    printf("O salário é de %.2f", total);
    
    
    
    
    
}  