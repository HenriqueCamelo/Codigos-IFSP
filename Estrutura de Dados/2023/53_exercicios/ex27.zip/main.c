#include <stdio.h>
#include <stdlib.h>

int main() {

    int anoat, idade,anonas;
    
    
    printf("Digite o ano atual: ");
    scanf("%d", &anoat);
    
    printf("Digite a sua idade: ");
    scanf("%d", &idade);
    
    anonas = anoat - idade;
    
    printf("Você nasceu em: %d", anonas);
    

   return 0;
}