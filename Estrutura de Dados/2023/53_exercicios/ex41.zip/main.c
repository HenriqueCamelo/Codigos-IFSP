#include <stdio.h>

int main()
{
    float graus, radianos;
    
    printf("Digite o ângulo em radianos que será convertida em graus: ");
    scanf("%f", &radianos);
    
    graus = radianos * 180/ 3.141592;
    
    printf("O ângulo em graus é: %.2f", graus);

    return 0;
}