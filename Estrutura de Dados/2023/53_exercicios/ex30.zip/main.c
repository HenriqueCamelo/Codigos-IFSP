#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float valor1, valor2, valor3, arreca, premio;
    float pc1, pc2, pc3;
    
    printf("Digite o quanto o primeiro amigo apostou: ");
    scanf("%f", &valor1);

    printf("Digite o quanto o segundo amigo apostou: ");
    scanf("%f", &valor2);
    
    printf("Digite o quanto o terceiro amigo apostou: ");
    scanf("%f", &valor3);
    
    printf("Digite o valor do prêmio: ");
    scanf("%f", &premio);
    
    arreca = valor1 + valor2 + valor3;
    
    pc1 = valor1/arreca;
    pc2 = valor2/arreca;
    pc3 = valor3/arreca;
    
    printf("\nO primeiro amigo ganharia: %.2f", pc1*premio);
    printf("\nO primeiro amigo ganharia: %.2f", pc2*premio);
    printf("\nO primeiro amigo ganharia: %.2f", pc3*premio);

   return 0;
}