#include <stdio.h>


float num1;
float aumento;



int main()
{
    printf("Digite o valor do seu antigo salário: \n"); 
    scanf("%f", &num1);
    
    
   
    aumento = num1 + (num1*0.25);
    
    
    
    printf("\n\nO preço a ser pago é: %.2f", aumento); 
}   
