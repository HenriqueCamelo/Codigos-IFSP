#include <stdio.h>


float num1, num2;
float area;



int main()
{
    printf("Digite o raio do cilindro: \n"); 
    scanf("%f", &num1);
    
    printf("Digite o tamanho da altura: \n"); 
    scanf("%f", &num2);
   
    area = (num1 * num1) * num2 * 3.141592;
    
    
    
    printf("\n\nA área do cilíndro é: %.6f", area); 
}   