#include <stdio.h>

int inte;
int quadrado;

int main()
{
    printf("Escreva numero inteiro : \n"); 
    scanf("%d", &inte);
    
    quadrado = inte*inte;
    
    printf("O quadrado deste númro é : %d \n", quadrado); 

    
}   