#include <stdio.h>

int intei;
float frac;

int main()
{
    printf("Escreva um número inteiro: \n"); 
    scanf("%d", &intei);
    
    printf("Escreva um número real: \n");
    scanf("%f", &frac);
    
    printf("Os números digitados foram: %d e %.2f ", intei, frac);
}   
