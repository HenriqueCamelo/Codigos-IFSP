#include <stdio.h>
#include <stdlib.h>

int main()
{
    int horas;
    int minutos;
    int segundos;
    
    printf("Digite a quantidade de segundos que deseja transformar em horas, minutos e segundos: ");
    scanf("%d", &segundos);
    
    horas = segundos/3600;
    minutos = (segundos - (3600*horas))/60;
    segundos = segundos - (horas*3600)-(minutos*60);
    
    printf("%dhoras: %dminutos: %dsegundos: ", horas, minutos, segundos);
    
    return 0;
}