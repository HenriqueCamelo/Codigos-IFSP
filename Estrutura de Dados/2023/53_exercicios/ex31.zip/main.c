#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float largura, comprimento, valorarame, preco, total;

    
    printf("Digite a largura do terreno: ");
    scanf("%f", &largura);

    printf("Digite o comprimento do terreno: ");
    scanf("%f", &comprimento);
    
    printf("Digite o valor por metro de arame: ");
    scanf("%f", &valorarame);
    
    total = (largura * 2) + (comprimento *2);
    
    printf("\nO total a pagar no arame para cobrir o perímetro é: %.2f", total * valorarame);
    
   return 0;
}