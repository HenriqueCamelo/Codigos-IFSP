#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float temperatura, Fahrenheit;

    
    printf("Digite a temperatura em celsius que será convertida: ");
    scanf("%f", &temperatura);
    
    Fahrenheit = temperatura*(9.0/5.0) + 32.0;
    
    printf("A temperatura em Fahrenheit é: %.2f", Fahrenheit);
    

   return 0;
}