#include <stdio.h>

int num1;
int antecessor;
int sucessor;

int main()
{
    printf("Escreva um número: \n"); 
    scanf("%d", &num1);
   
    antecessor = num1 - 1; 
    sucessor = num1 + 1;
    
    printf("\n\nO seu antecessor é %d, e seu sucessor é %d", antecessor, sucessor); 
}   