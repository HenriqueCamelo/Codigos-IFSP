#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

    float kilometro, metros;

    
    printf("Digite a velocidade em m/s que será convertida: ");
    scanf("%f", &metros);
    
    kilometro = metros * 3.6;
    
    printf("A velocidade em km/h é: %.2f", kilometro);
    

   return 0;
}
